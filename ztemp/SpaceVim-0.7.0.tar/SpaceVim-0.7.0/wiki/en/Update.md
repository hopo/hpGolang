Read <kbd>:h SPUpdate</kbd>, for example you can update SpaceVim with the command below:

```viml
:SPUpdate SpaceVim
```
after updating done, you will see:
![2017-04-18-21 00 11](https://cloud.githubusercontent.com/assets/13142418/25132063/ba1cb6e0-247a-11e7-99cc-60c206624921.png)
