---
title: "Install vim/neovim with python support"
categories: tutorials
excerpt: "How to build vim or neovim from source with python enabled?"
comments: true
---


Installation of neovim/vim with python support:

> [neovim installation](https://github.com/neovim/neovim/wiki/Installing-Neovim)

> [Building Vim from source](https://github.com/Valloric/YouCompleteMe/wiki/Building-Vim-from-source)
