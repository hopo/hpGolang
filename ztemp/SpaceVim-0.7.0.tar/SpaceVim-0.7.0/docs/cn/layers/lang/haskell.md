---
title: "SpaceVim lang#javascript layer"
description: "This layer is for haskell development"
---

# [SpaceVim Layers:](https://spacevim.org/layers) lang#haskell

<!-- vim-markdown-toc GFM -->

- [Description](#description)
- [Layer Installation](#layer-installation)
- [Features](#features)

<!-- vim-markdown-toc -->

## Description

This layer is for haskell development.

## Layer Installation

To use this configuration layer, add `call SpaceVim#layers#load('lang#haskell')` to your custom configuration file.

## Features

- auto-completion
- syntax checking
- goto definition
- refernce finder
- language server protocol (need lsp layer) 

