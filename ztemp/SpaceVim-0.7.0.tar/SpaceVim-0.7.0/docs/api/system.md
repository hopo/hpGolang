---
title: "system api"
---

# [APIs](https://spacevim.org/apis) : system

## values

name   | values | description
----- |:----:| ------------------
isWindows | 0 or 1 | check if the os is windows
isLinux | 0 or 1 | check if the os is linux
isOSX | 0 or 1 | check if the os is OSX

## functions
