<!-- please remove the issue template when request for a feature -->
## Expected behavior, english is recommended


## Environment Information
- OS:
- vim version:
- neovim version:

## The reproduce ways from Vim starting (Required!)


## Output of the ':SPDebugInfo!'

please post log below, if you want me to reproduce your issue quickly, including your custom config here will be better.

## Screenshots

If you have any screenshots for this issue, please upload here. BTW you can use https://asciinema.org/ for recording video in terminal.

