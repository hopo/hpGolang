# [Layers](https://spacevim.org/layers) > default

SpaceVim default layer contains none plugins, but it has some better default config for vim and neovim.

## Key Mappings
