---
title: Newsletter #1 - A New Hope
categories: newsletter
excerpt: "A new hope: turn vim/neovim to be an IDE for most languages"
---

# [newsletter](https://spacevim.org/development#newsletter) > A New Hope

Welcome to the first newsletter for SpaceVim, a project that hopes to turn vim to be an IDE for most languages.
