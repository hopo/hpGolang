[[[https://github.com/SpaceVim/SpaceVim/raw/dev/docs/logo.png|alt=SpaceVim home]]](Home)
--
[Introduction](Introduction)   
[Community](https://spacevim.org/community/)  
[FAQ](FAQ)  
[Layers](https://spacevim.org/layers/)

**Users**  
[Install](Installing-SpaceVim)  
[Docs](http://spacevim.org/documentation/)

**Developers**  
[Contribute](https://spacevim.org/development/)  
[Tips & Tools](Development-tips)  
[Code style](http://spacevim.org/conventions/)  
