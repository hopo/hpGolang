- [Introduction](Introduction)  
- **[FAQ](FAQ)**
- [Progress/Roadmap](Progress)
- [Features](Features)
- [Project layout](project_layout)

## Users

- [Documentation](https://spacevim.org/documentation)
    - [Quick start guide](quick-start-guide)
- [Getting Help](getting-help)
- [Install](Installing-SpaceVim)
- [Update](Update)
- [Community](http://spacevim.org/community/)

## Developers

- [Support SpaceVim](support-spacevim)
    - [contribute to SpaceVim](contribute-to-spacevim)
    - [Write post about SpaceVim](write-post-about-spacevim)
- [Credits & Thanks](credits--thanks)
