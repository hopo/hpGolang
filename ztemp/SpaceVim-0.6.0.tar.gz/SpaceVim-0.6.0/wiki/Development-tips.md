steps of sending a PR:

1. fork this repo
2. checkout new branch from dev branch
3. push your commits
4. sending pull request



