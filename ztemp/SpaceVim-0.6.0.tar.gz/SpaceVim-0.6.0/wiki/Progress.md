See the [Roadmap](https://spacevim.org/roadmap/) and [<kbd>:help SpaceVim-features</kbd>](https://spacevim.org/doc/user/vim_diff.html#nvim-features).
